# Geeta — multilingual narration handoff

The complete original adaptation is prepared in English, Hindi, Japanese, Simplified Chinese (Mandarin), and French. Each language has **18 chapters, 72 scenes and 194 spoken passages**, including the four-passage prologue. The narration covers dialogue and storytelling; explanations, examples, reflections and Sanskrit are available separately in Read mode.

**Audio has not been generated.** The site displays an honest availability message in Listen mode until recordings are supplied. It does not use device speech as a substitute. The translations are complete agent-authored drafts; their structure and coverage are checked. They have not been certified by independent native-language editors or tested with the final voices.

## What is included

- `recording-manifest.json`: all 970 expected recordings, stable IDs, source speaker keys and hashes of the spoken text.
- Each language's `script.md`: complete human-readable narration script.
- Each language's `recordings.csv` and `recordings.jsonl`: passage ID, source speaker key, localized speaker name, exact spoken text and output filename.
- Each language's `passages/*.txt`: one clean spoken passage per file, with no headers or IDs for the voice to read aloud.
- Language-specific `*-notes.md`: names, pronunciations, terminology and interpretive considerations.
- `source-notes.md`: the adaptation's existing source and context notes.

## V7 active story

The active experience now uses **188 passages per language (940 total)**. It begins at `1.1.2` with Arjun and ends at `18.4.4` with his resolution. Skip `0.0.1` through `0.0.4`, `1.1.1` and `18.4.5` during new audio production. `active-passage-ids.json` lists the exact active IDs. The original 970 files remain as a preserved source archive; existing recording IDs are unchanged. Sanjaya-keyed descriptions retained inside the story are displayed as field context, without introducing a separate named narrator.

## Voice direction

For the active story, keep three consistent speaking roles across languages: Arjun, Krishna and neutral contextual narration (the preserved Sanjaya key). The Dhritarashtra role belongs only to the archived prologue. Choose a native or convincingly fluent voice for each target language; consistency refers to character and temperament, rather than requiring one voice to perform all five languages.

| Source speaker key | Direction |
| --- | --- |
| Sanjaya | Clear, measured storyteller; warm without sounding like a trailer. |
| Dhritarashtra | An older king asking the opening question, attentive and unsettled. |
| Arjun | Thoughtful and human; strain, wonder and fear gradually give way to steadiness. |
| Krishna | Calm, present and assured. Authority through clarity, with no booming deity effect. |

Record and listen to short samples before producing the complete set: the opening character captions, Arjun's trembling hand in 1.2, Krishna's “I am Time” in 11.3, and the final exchange in 18.4. Check names and philosophical terms against each language's notes. Keep the final vow and surrender passages complete. Chapter XI contains both awe and fear; it should not sound triumphant during destruction.

## ElevenLabs production step

The CSV/JSONL files are general production manifests, not a claim that ElevenLabs has a one-click import format for them. When generating via the selected ElevenLabs workflow, submit only each row's `text`, route `speakerKey` to the chosen voice, and save the result using `filename`.

1. Choose and audition the voices for each language.
2. Check the translations and pronunciation samples before paying for a full production run.
3. Generate one recording per passage. Do not speak the IDs, chapter labels, speaker labels, English staging metadata or translation notes.
4. Export MP3s under language folders using the exact names in the manifest, for example `hi/11.3.1.mp3`. Keep the same voice, recording level and leading/trailing silence treatment within each role.
5. Import a recordings folder with `node scripts/import-narration.mjs /absolute/path/to/recordings`, then save and publish the Site. The importer checks the file signature and registers only files that exist. Audio review is still needed: an MP3 signature cannot establish correct words, voice, duration or pronunciation.

Never place an ElevenLabs API key in the public Site or this handoff. Audio generation happens separately; the finished experience serves the exported recordings directly.

## Synchronization

All five languages share the same 194 passage IDs. A recording's real end advances the story to the next passage. There are no guessed reading-time timers. Pause, previous/next, speed, seeking, language changes and chapter jumps use the same story position.

The approved Chapter XI's ten visual cues are mapped to the complete chapter's fourteen spoken passages, including the reassuring four-armed form and return to Krishna. The introduction, speaker-context panels and settings are translated separately in `dist/narrative/experience-copy.js`; they are interface copy, not additional spoken recording IDs. The opening now includes a moving rath arrival. During the teaching, Krishna faces Arjun and Arjun kneels with joined palms. Battlefield ambience and staged daylight changes run independently of the narration. The 970 spoken scripts and their stable IDs are unchanged.

Read mode is complete without WebGL or narration files. Listen mode will play only recordings that have been supplied. A missing or failed recording stops progression; it never silently skips a passage or substitutes another language. Audio starts only after the listener presses play. The player reuses one audio element across passages, handles rejected playback, and keeps playback and source controls visible.

Implementation references: [HTMLMediaElement.play](https://developer.mozilla.org/en-US/docs/Web/API/HTMLMediaElement/play) and [ended event](https://developer.mozilla.org/en-US/docs/Web/API/HTMLMediaElement/ended_event). No browser or real voice playback review was performed in this editing pass.

## Opening and source panel

The revised experience includes a five-stage introductory film in text and battlefield ambience. The five-language caption script is in `dist/narrative/flow-copy.js`; it introduces the opposing clans, Arjuna, Krishna, the Geeta title and the question between the armies, then leads directly into Arjun’s first words. These 25 introductory captions are separate from the unchanged 970 spoken-passage scripts. Recording and synchronizing the opening narration remains a subsequent audio-production step.

Read mode now has explicitly started automatic progression at a reading pace. This clock is entirely separate from Listen mode: narration still advances only on real recording completion. Opening Shloka & meaning in Listen mode leaves audio playing and updates the source panel as the current passage changes.


## Closing and voice-over integration

The active experience ends on Arjun's `18.4.4` in each language. Its actual audio `ended` event begins the 21-second closing only after that recording finishes. Missing, failed, paused or stale audio does not count as completion. The same closing is available via Finish in manual Read and from reading autoplay completion. Do not add silence to simulate the closing inside the recording; the separate timeline owns the hold, pullback, sound envelope and end screen.

The visible interface no longer shows helper captions such as “Opening credits.” Submit only the passage `text` to voice generation, excluding interface labels, titles, controls and internal IDs. The closing reflection is silent screen text. No new ending narration or voice files were generated in this implementation. The existing scripts and importer remain the production handoff for the next voice-over step.
